//"""
Author: CIT-223-035/2017
"""
def gen_abbrev( word):

    vowels = ['A', 'E', 'I', 'O', 'U', ' ']
    word = word.upper()
    abbrev = "" + word[0]
    if len(word) > 2:
        middle_index = int(len(word)/2)
        while word[middle_index] in vowels:
            middle_index -= 1
            if middle_index == 0:
                return abbrev + word[middle_index]
        last_index = -1
        while word[last_index] in vowels:
            last_index -=1
            if last_index * -1 == len(word):
                return abbrev + word[middle_index]
        abbrev = abbrev + word[middle_index] + word[last_index]
    else:
        abbrev = abbrev + word[-1]
    return abbrev
 


filename = "cities.txt"
output_filename = "cities_cleaned_and_tagged.txt"


cities_sorted = []
cities_abbrev = []
label_tag = "<label for=\"city\">City of Residence</label>"
input_tag = "<input type=\"text\" id=\"city\" required list=\"cities\">"
datalist_tag0 = "<datalist id=\"cities\">"
datalist_tag1 = "</datalist>"
option0 = "<option value=\""
option1 = "\">"
option2 = "</option>"

with open(filename) as f_obj:
    lines = f_obj.readlines()

for line in lines:
    line = line.rstrip()
    cities_sorted.append(line.capitalize())
    cities_sorted.sort()
for city in cities_sorted:
    cities_abbrev.append(gen_abbrev(city))

with open(filename, 'w') as f:
    for i in range(0, len(cities_sorted)):
        f.write(cities_sorted[i] + "\n")

with open(output_filename, 'w') as f:
    f.write(label_tag + "\n")
    f.write(input_tag + "\n")
    f.write(datalist_tag0 + "\n")
    for i in range(0, len(cities_sorted)):
        f.write("\t" + option0 + cities_abbrev[i] + option1 + cities_sorted[i] + option2 + "\n")
    f.write(datalist_tag1)
